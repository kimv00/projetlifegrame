//
//  EffetController.swift
//  LifeGram
//
//  Created by Toure on 28/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

class EffetController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    var image: UIImage!

    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = image

    }
}
