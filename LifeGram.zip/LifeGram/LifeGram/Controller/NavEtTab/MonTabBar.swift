//
//  MonTabBar.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

class MonTabBar: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(notifVue), name: Notification.Name("Vue"), object: nil)
        
        tabBar.backgroundColor = .white
        tabBar.tintColor = .black
        
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        
        let fil = FilController(collectionViewLayout: layout)
        let notif = NotificationController(style: .plain)
        let profil = ProfilController(collectionViewLayout: layout)
        
        
        viewControllers = [
            ajouter(controller: fil, image: #imageLiteral(resourceName: "tab_accueil"), titre: "accueil"),
            ajouter(controller: RechercheController(), image: #imageLiteral(resourceName: "Search"), titre: "Recherche"),
            ajouter(controller: PhotoController(), image: #imageLiteral(resourceName: "tab_photo"), titre: ""),
            ajouter(controller: notif, image: #imageLiteral(resourceName: "tab_notif"), titre: "notifications"),
            ajouter(controller: profil, image: #imageLiteral(resourceName: "profil"), titre: "profil")
        ]
        observerNotifs()
    }
    
    @objc func notifVue(notification: Notification) {
        observerNotifs()
    }
    
    func observerNotifs() {
        NOTIF = [Notif]()
        BDD().recupererNotification { (notif) -> (Void) in
            if notif != nil {
                if let index = NOTIF.index(where: {$0.id == notif!.id}) {
                    NOTIF[index] = notif!
                } else {
                    NOTIF.append(notif!)
                }
                NOTIF = NOTIF.sorted(by: {$0.date > $1.date})
                NotificationCenter.default.post(name: Notification.Name("Notif"), object: nil)
                self.ajouterBadge()
            }
        }
    }
    
    @objc func ajouterBadge() {
        guard let items = self.tabBar.items, items.count == 5 else { return }
        var nonLus = [Notif]()
        for n in NOTIF {
            if !n.vue {
                nonLus.append(n)
            }
        }
        if nonLus.count > 0 {
            items[3].badgeValue = String(nonLus.count)
        } else {
            items[3].badgeValue = nil
        }
    }
    
    func ajouter(controller: UIViewController, image: UIImage, titre: String) -> UINavigationController {
        let nav = MonNav(rootViewController: controller)
        nav.tabBarItem.image = image
        nav.tabBarItem.title = titre
        return nav
    }
}
