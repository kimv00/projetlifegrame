//
//  PostUniqueController.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

class PostUniqueController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var postVue: PostVue!
    @IBOutlet weak var largeurContrainte: NSLayoutConstraint!
    @IBOutlet weak var hauteurContrainte: NSLayoutConstraint!
    
    var post: Post!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let largeur = view.frame.width
        let texte = self.post.texte + "\n" + self.post.date.ilYA()
        let hauteurDeTexte = texte.rect(largeur: largeur - 20, font: UIFont.systemFont(ofSize: 18)).height
        let hauteurTotale = 150 + largeur + hauteurDeTexte
        
        largeurContrainte.constant = largeur
        hauteurContrainte.constant = hauteurTotale
        
        postVue.miseEnPlace(post: self.post, filController: nil, profilController: nil, postUniqueController: self)
    }
}
