//
//  NotificationController.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit
import FirebaseDatabase

class NotificationController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: NOTIF_TB, bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: NOTIF_TB)
        NotificationCenter.default.addObserver(self, selector: #selector(ajoutNotif), name: Notification.Name("Notif"), object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { (timer) in
            for n in NOTIF {
                n.ref.updateChildValues(["vue": true as AnyObject])
            }
            NotificationCenter.default.post(name: Notification.Name("Vue"), object: nil)
        }
    }
    
    @objc func ajoutNotif(notification: Notification) {
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return NOTIF.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: NOTIF_TB) as! NotifCell
        cell.miseEnPlace(notif: NOTIF[indexPath.row], controller: self)
        
        return cell
    }
}
