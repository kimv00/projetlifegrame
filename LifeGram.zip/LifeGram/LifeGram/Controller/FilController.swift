//
//  FilController.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

class FilController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    var posts = [Post]()
    var hashtag: Hashtag?
    var utilisateurArray = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView?.backgroundColor = .white
        collectionView?.register(PostCell.self, forCellWithReuseIdentifier: POST_CELL)
        collectionView?.delegate = self
        if hashtag != nil {
            recupererHash()
            title = hashtag!.nom
            
        } else {
            recupererTousLesPosts()
        }
        }
    
    override func viewWillAppear(_ animated: Bool) {
        if hashtag == nil {
            var array = MOI.abonnements
            array.append(MOI.id)
            if array != utilisateurArray {
                posts = [Post]()
                collectionView?.reloadData()
                recupererTousLesPosts()
            }
        }
    }
    
    // trie des posts
    func trierEtReload() {
        self.posts = self.posts.sorted(by: {$0.date > $1.date})
        self.collectionView?.reloadData()
    }
    
    func recupererHash() {
        BDD().recupererPostsHashtag(dict: hashtag!.posts) { (post) -> (Void) in
            if post != nil {
                self.verifierSiPostExistee(post: post!)
            }
        }
    }
    
    func verifierSiPostExistee(post: Post) {
        if let index = self.posts.index(where: {$0.id == post.id}) {
            self.posts[index] = post
        } else {
            self.posts.append(post)
        }
        self.trierEtReload()
    }
    
    func recupererTousLesPosts() {
        var utilisateursAParser = MOI.abonnements
        utilisateursAParser.append(MOI.id)
        utilisateurArray = utilisateursAParser
        for utilisateur in utilisateursAParser {
            BDD().recupererPost(utilisateur: utilisateur, completion: { (post) -> (Void) in
                if post != nil {
                    self.verifierSiPostExistee(post: post!)
                }
            })
        }
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return posts.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: POST_CELL, for: indexPath) as! PostCell
        cell.miseEnPlace(fil: self, profil: nil, post: posts[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let post = posts[indexPath.row]
        let largeur = collectionView.frame.width
        var hauteur = 150 + largeur
        let texte = post.texte + "\n" + post.date.ilYA()
        hauteur += texte.rect(largeur: collectionView.frame.width, font: UIFont.systemFont(ofSize: 18)).height
        return CGSize(width: largeur, height: hauteur)
    }
}
