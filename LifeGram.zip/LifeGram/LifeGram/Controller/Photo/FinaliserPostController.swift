//
//  FinaliserPostController.swift
//  CodaGram
//
//  Created by Matthieu PASSEREL on 19/01/2018.
//  Copyright © 2018 Matthieu PASSEREL. All rights reserved.
//

import UIKit

class FinaliserPostController: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var imageDeProfil: ImageArrondie!
    @IBOutlet weak var imageDuPost: UIImageView!
    @IBOutlet weak var textView: UITextView!
    
    var image: UIImage!
    var peutAjouter = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clavier()
        imageDuPost.image = image
        textView.delegate = self
        let suivant = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(finaliserPost))
        navigationItem.rightBarButtonItem = suivant
    }
    
    @objc func finaliserPost() {
        self.view.endEditing(true) // permet de fermet notre clavier apres un post 
        if peutAjouter {
            peutAjouter = false
            verifierTextView()
            
            //Enregistrer l'image dans le stockage
            guard let data = UIImageJPEGRepresentation(image, 0.5) else { return }
            view.creerActivityIndicator()
            let idUnique = UUID().uuidString
            Stockage().ajouterPostImage(reference: Ref().mesPostsImage.child(idUnique), data: data) { (success, string) -> (Void) in
                //Le stockage va me renvoyer un URLString
                self.peutAjouter = true
                self.view.supprimmerActivityIndicator()
                if let reussite = success, reussite == true, string != nil {
                    let dict: [String: AnyObject] = [
                        "imageUrl": string! as AnyObject,
                        "id": MOI.id as AnyObject,
                        "texte": self.textView.text as AnyObject,
                        "date": Date().timeIntervalSince1970 as AnyObject
                    ]
                    //Ajouter notre post à notre base de données avec URLString
                    BDD().creerPost(dict: dict)
                    self.navigationController?.popToRootViewController(animated: true)
                }
            }
        }
    }
    
    func verifierTextView() {
        if textView.text == "Ecrivez quelque chose..." {
            textView.text = ""
        }
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        verifierTextView()
    }
}
