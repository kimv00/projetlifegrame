//
//  ModifierController.swift
//  CodaGram
//
//  Created by Matthieu PASSEREL on 23/01/2018.
//  Copyright © 2018 Matthieu PASSEREL. All rights reserved.
//

import UIKit

class ModifierController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var imageDeFond: UIImageView!
    @IBOutlet weak var imageDeProfil: ImageArrondie!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var erreurUsername: UILabel!
    @IBOutlet weak var prenomTextField: UITextField!
    @IBOutlet weak var nomTextField: UITextField!
    @IBOutlet weak var descTextView: UITextView!
    @IBOutlet weak var validerBouton: LifeGramBouton!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var largeurContrainte: NSLayoutConstraint!
    
    @IBOutlet weak var decoBouton: UIButton!
    var peutCreerUsername = false
    var picker: UIImagePickerController?
    var hauteurdeScroll: CGFloat?
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        largeurContrainte.constant = view.frame.width
        hauteurdeScroll = decoBouton.frame.maxY + 60
        scrollView.contentSize = CGSize(width: view.frame.width, height: hauteurdeScroll!)
        scrollView.layoutIfNeeded()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker = UIImagePickerController()
        picker?.allowsEditing = true
        picker?.delegate = self
        NotificationCenter.default.addObserver(self, selector: #selector(clavierIn), name: Notification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(clavierOut), name: Notification.Name.UIKeyboardWillHide, object: nil)
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(rentrer)))
        imageDeFond.telecharger(imageUrl: MOI.imageUrl)
        imageDeProfil.telecharger(imageUrl: MOI.imageUrl)
        imageDeProfil.isUserInteractionEnabled = true
        imageDeProfil.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(prendrePhoto)))
        usernameTextField.text = MOI.username
        usernameTextField.addTarget(self, action: #selector(texteMisAJour(_:)), for: .editingChanged)
        if MOI.prenom == "" {
            prenomTextField.placeholder = "Entrez votre prénom"
        } else {
            prenomTextField.text = MOI.prenom
        }
        
        if MOI.nom == "" {
            nomTextField.placeholder = "Entrez votre nom"
        } else {
            nomTextField.text = MOI.nom
        }
        
        descTextView.text = MOI.desc
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var monImage: UIImage?
        if let modifiee = info[UIImagePickerControllerEditedImage] as? UIImage {
            monImage = modifiee
        } else if let originale = info[UIImagePickerControllerOriginalImage] as? UIImage {
            monImage = originale
        }
        self.picker?.dismiss(animated: true, completion: nil)
        guard monImage != nil, let data = UIImageJPEGRepresentation(monImage!, 0.2) else { return }
        view.creerActivityIndicator()
        Stockage().ajouterPostImage(reference: Ref().monProfilImage, data: data) { (success, urlString) -> (Void) in
            self.view.supprimmerActivityIndicator()
            guard let resultat = success, resultat == true, urlString != nil  else { return }
            BDD().miseAjourUtilisateur(dict: ["imageUrl": urlString! as AnyObject], completion: { (utilisateur) -> (Void) in
                if utilisateur != nil {
                    MOI = utilisateur!
                    self.imageDeFond.telecharger(imageUrl: MOI.imageUrl)
                    self.imageDeProfil.telecharger(imageUrl: MOI.imageUrl)
                }
            })
        }
    }
    
    @objc func prendrePhoto() {
        Alerte().camera(controller: self, picker: picker!)
    }
    
    @objc func rentrer() {
        view.endEditing(true)
    }
    
    @objc func clavierIn(notification: Notification) {
        if let clavierHauteur = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.height , hauteurdeScroll != nil {
            UIView.animate(withDuration: 0.5, animations: {
                self.scrollView.contentSize = CGSize(width: self.view.frame.width, height: self.hauteurdeScroll! + clavierHauteur)
            })
            
        }
    }
    
    @objc func clavierOut(notification: Notification) {
        if hauteurdeScroll != nil {
            UIView.animate(withDuration: 0.5) {
                self.scrollView.contentSize = CGSize(width: self.view.frame.width, height: self.hauteurdeScroll!)
            }
        }
    }
    
    @objc func texteMisAJour(_ textField: UITextField) {
        guard let nouveauUsername = textField.text else { return }
        if nouveauUsername == "" {
            peutCreerUsername = false
            erreurUsername.text = "Le nom d'utilisateur ne peut pas être vide"
        } else if nouveauUsername.contains(" ") {
            peutCreerUsername = false
            erreurUsername.text = "Le nom d'utilisateur ne peut pas contenir d'espace"
        } else if nouveauUsername.count >= 20 {
            peutCreerUsername = false
            erreurUsername.text = "Nom d'utilisateur trop long"
        } else {
            BDD().usernameExiste(username: nouveauUsername, completion: { (success, error) -> (Void) in
                guard success != nil, error != nil else { return }
                self.peutCreerUsername = success!
                self.erreurUsername.text = error!
            })
        }
    }
    
    
    @IBAction func validerAction(_ sender: Any) {
        view.endEditing(true)
        var dict = [String: AnyObject]()
        if prenomTextField.text != nil {
            dict["prenom"] = prenomTextField.text! as AnyObject
        }
        if nomTextField.text != nil {
            dict["nom"] = nomTextField.text! as AnyObject
        }
        
        if usernameTextField.text != nil, peutCreerUsername == true {
            dict["username"] = usernameTextField.text! as AnyObject
        }
        
        if descTextView.text != "" {
            dict["desc"] = descTextView.text as AnyObject
        }
        BDD().miseAjourUtilisateur(dict: dict) { (utilisateur) -> (Void) in
            if utilisateur != nil {
                MOI = utilisateur!
                self.navigationController?.popViewController(animated: true)
            }
        }
        
    }
    
    @IBAction func decoAction(_ sender: Any) {
        Alerte().deconnection(controller: self)
    }
    
}











