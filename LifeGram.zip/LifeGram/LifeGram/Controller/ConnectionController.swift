//
//  ConnectionController.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit
import FirebaseAuth

class ConnectionController: UIViewController {
    
    var logoVue: LogoVue!
    var connectionVue: ConnectionVue!
    var usernameVue: UsernameVue!
    
    var vueActuelle: UIView!
    var monMail: String?
    var monMotDePasse: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clavier()
        view.backgroundColor = .white
        logoVue = LogoVue(frame: view.bounds)
        connectionVue = ConnectionVue(frame: view.bounds)
        connectionVue.ajoutController(controller: self)
        usernameVue = UsernameVue(frame: view.bounds)
        usernameVue.ajouterController(controller: self)
        view.addSubview(logoVue)
        vueActuelle = logoVue
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let id = Auth.auth().currentUser?.uid {
            verifierUtilisateur(id: id)
        } else {
            transition(vers: connectionVue, transition: .transitionFlipFromRight)
        }
    }
    
    
    
    func validerConnection(adresseMail: String?, motDePasse: String?) {
        monMail = adresseMail
        monMotDePasse = motDePasse
        if let mail = monMail, mail != "" {
            if let mdp = monMotDePasse, monMotDePasse != "" {
                //Voir avec Firebase
                Auth.auth().signIn(withEmail: mail, password: mdp, completion: { (user, error) in
                    if let erreur = error {
                        let nsErreur = erreur as NSError
                        if nsErreur.code == 17011 {
                            Auth.auth().createUser(withEmail: mail, password: mdp, completion: { (user, error) in
                                if let erreur = error {
                                    Alerte().erreurSimple(controller: self, message: erreur.localizedDescription)
                                }
                                if user != nil {
                                    //Transition vers UsernameVue
                                    self.transition(vers: self.usernameVue, transition: .transitionFlipFromRight)
                                }
                            })
                        } else {
                            Alerte().erreurSimple(controller: self, message: erreur.localizedDescription)
                        }
                    }
                    if let id = user?.user.uid {
                        //Verifier si utilisateur existe
                        self.verifierUtilisateur(id: id)
                    }
                })
            } else {
                Alerte().erreurSimple(controller: self, message: "Le mot de passe ne peut pas être vide")
            }
        } else {
            Alerte().erreurSimple(controller: self, message: "L'adresse mail ne peut pas être vide")
        }
    }
    
    func transition(vers: UIView, transition: UIViewAnimationOptions) {
        UIView.transition(from: vueActuelle, to: vers, duration: 1, options: transition) { (success) in
            self.vueActuelle = vers
        }
    }
    
    func verifierUtilisateur(id: String) {
        BDD().recupererUtilisateur(id: id) { (utilisateur) -> (Void) in
            if utilisateur != nil {
                MOI = utilisateur!
                self.versApp()
            } else {
                self.transition(vers: self.usernameVue, transition: .transitionFlipFromRight)
            }
        }
    }
    
    func versApp() {
        //Instancier TabBARController
        if self.viewIfLoaded?.window != nil {
            let tab = MonTabBar()
            self.present(tab, animated: true, completion: nil)
        }
    }
}
