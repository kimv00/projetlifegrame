//
//  BDD.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import Foundation
import FirebaseDatabase
import FirebaseAuth

class BDD {
    
    func recupererUtilisateur(id: String, completion: UtilisateurCompletion?) {
        Ref().utilisateurSpecifique(id: id).observe(.value) {(snapshot) in
            if snapshot.exists(), let _ = snapshot.value as? [String: AnyObject] {
                completion?(Utilisateur(snapshot: snapshot))
            } else {
                completion?(nil)
            }
        }
    }
    
    func recupererTousLesUtilisateurs(completion: UtilisateurCompletion?) {
        Ref().racineUtilisateur.observe(.childAdded) { (snapshot) in
            completion?(Utilisateur(snapshot: snapshot))
        }
    }
    
    func usernameExiste(username: String, completion: SuccessCompletion?) {
        Ref().racineUtilisateur.queryOrdered(byChild: "username").queryEqual(toValue:
            username).observeSingleEvent(of: .value) { (snapshot) in
            if !snapshot.exists() {
                completion?(true, "")
            } else {
                completion?(false, "Nom d'utilisateur deja pris")
            }
        }
    }
    
    func miseAjourUtilisateur(dict: [String: AnyObject], completion: UtilisateurCompletion?) {
        guard let id = Auth.auth().currentUser?.uid else { completion?(nil); return }
        Ref().utilisateurSpecifique(id: id).updateChildValues(dict) {(error, ref) in
            if error == nil {
                self.recupererUtilisateur(id: id, completion: { (utilisateur) -> (Void) in
                    completion?(utilisateur)
                })
            }
        }
    }
    
    func mettreAJourPost(postId: String, userId: String, dict: [String: AnyObject]) {
        Ref().postSpecifique(key: postId, value: userId).updateChildValues(dict)
    }
    
    func creerPost(dict: [String: AnyObject]) {
        Ref().mesPostsBDD.childByAutoId().updateChildValues(dict) { (error, ref) in
            guard error == nil, let postId = ref.description().components(separatedBy: "/").last else { return }
            guard let string = dict["texte"] as? String else { return }
            let mots = string.components(separatedBy: " ")
            for mot in mots {
                if mot.hasPrefix("#") {
                    self.ajouterHashtag(postId: postId, mot: mot)
                }
            }
        }
    }
    
    func envoyerCommentaire(ref: DatabaseReference, dict: [String: AnyObject]) {
        Ref().commentaireDepuisRef(ref: ref).childByAutoId().updateChildValues(dict)
    }
    
    
     func recupererCommentaire(ref: DatabaseReference, completion: CommentaireCompletion?) {
        Ref().commentaireDepuisRef(ref: ref).observe(.childAdded) { (snapshot) in
            if let dict = snapshot.value as? [String: AnyObject] {
                if let utilisateurId = dict["utilisateur"] as? String {
                    self.recupererUtilisateur(id: utilisateurId, completion: { (utilisateur) -> (Void) in
                        if utilisateur != nil {
                            let nouveauCommentaire = Commentaire(ref: snapshot.ref, id: snapshot.key, utilisateur: utilisateur!, dict: dict)
                            completion?(nouveauCommentaire)
                        } else {
                            completion?(nil)
                        }
                    })
                }
            } else {
                completion?(nil)
            }
        }
    }
    
    func recuperHahtags(completion: HashtagCompletion?) {
        Ref().racineHashtag.observe(.childAdded) { (snapshot) in
            if let dict = snapshot.value as? [String: String] {
                let nomDecode = snapshot.key.decodage()
                let nouveauHashtag = Hashtag(nom: nomDecode, posts: dict)
                completion?(nouveauHashtag)
            }
        }
    }
    
    func ajouterHashtag(postId: String, mot: String) {
        Ref().hashtagSpecifique(hashtag: mot.codage()).updateChildValues([postId: MOI.id])
    }
    
    func recupererPost(utilisateur: String, completion: PostCompletion?) {
        recupererUtilisateur(id: utilisateur) { (util) -> (Void) in
            if util != nil {
                Ref().postUtilisateurSpecifique(id: utilisateur).observe(.childAdded, with: { (snapshot) in
                    completion?(self.convertirPost(utilisateur: util!, snapshot: snapshot))
                })
            }
        }
    }
    
    func convertirPost(utilisateur: Utilisateur, snapshot: DataSnapshot) -> Post? {
        let postId = snapshot.key
        if let dict = snapshot.value as? [String: AnyObject] {
            return Post(ref: snapshot.ref, id: postId, utilisateur: utilisateur, commentaires: [], dict: dict)
        } else {
            return nil
        }
    }
    
    func recupererPostsHashtag(dict: [String: String], completion: PostCompletion?) {
        for (key, value) in dict {
            recupererUtilisateur(id: value, completion: { (util) -> (Void) in
                if let utilisateur = util {
                    Ref().postSpecifique(key: key, value: value).observe(.value, with: { (snapshot) in
                        completion?(self.convertirPost(utilisateur: utilisateur, snapshot: snapshot))
                    })
                } else {
                    completion?(nil)
                }
            })
            
        }
    }
    
    
    func ajoutLike(utilisateur: Utilisateur, suivre: Bool, completion: UtilisateurCompletion?) {
        var mesAbonnements = MOI.abonnements
        var sesAbonnes = utilisateur.abonnes
        if suivre {
            mesAbonnements.append(utilisateur.id)
            sesAbonnes.append(MOI.id)
            let dict: [String: AnyObject] = [
                "date": Date().timeIntervalSince1970 as AnyObject,
                "texte": "A commencé à vous suivre" as AnyObject,
                "utilisateur": MOI.id as AnyObject,
                "vue": false as AnyObject
            ]
            envoyerNotification(id: utilisateur.id, dict: dict)
        } else {
            if let indexAbonnes = sesAbonnes.index(of: MOI.id) {
                sesAbonnes.remove(at: indexAbonnes)
            }
            if let indexAbonnements = mesAbonnements.index(of: utilisateur.id) {
                mesAbonnements.remove(at: indexAbonnements)
            }
        }
        miseAjourUtilisateur(dict: ["abonnements" : mesAbonnements as AnyObject], completion: { (utilisateur) -> (Void) in
            if utilisateur != nil {
                MOI = utilisateur!
            }
        })
        Ref().utilisateurSpecifique(id: utilisateur.id).updateChildValues(["abonnes": sesAbonnes as AnyObject])
        BDD().recupererUtilisateur(id: utilisateur.id, completion: { (util) -> (Void) in
            completion?(util)
        })
    }
    
    func envoyerNotification(id: String, dict: [String: AnyObject]) {
        Ref().notifUtilisateur(id: id).childByAutoId().updateChildValues(dict)
    }
    
    func recupererNotification(completion: NotifCompletion?) {
       Ref().mesNotifs.observe(.childAdded) { (snapshot) in
            if let dict = snapshot.value as? [String: AnyObject] {
                if let utilisateurId = dict["utilisateur"] as? String {
                    self.recupererUtilisateur(id: utilisateurId, completion: { (util) -> (Void) in
                        if util != nil, let date = dict["date"] as? Double, let texte = dict["texte"] as? String, let vue = dict["vue"] as? Bool {
                            if let postId = dict["post"] as? String {
                                self.recupererPostsHashtag(dict: [postId: MOI.id], completion: { (post) -> (Void) in
                                    if post != nil {
                                        let notif = Notif(ref: snapshot.ref, id: snapshot.key, utilisateur: util!, post: post!, date: date, texte: texte, vue: vue)
                                        completion?(notif)
                                    }
                                })
                            } else {
                                let notifSansPost = Notif(ref: snapshot.ref, id: snapshot.key, utilisateur: util!, post: nil, date: date, texte: texte, vue: vue)
                                completion?(notifSansPost)
                            }
                        }
                    })
                }
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
