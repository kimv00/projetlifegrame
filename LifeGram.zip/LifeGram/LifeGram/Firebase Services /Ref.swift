//
//  Ref.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import Foundation
import FirebaseDatabase
import FirebaseStorage

class Ref {
    
    let bdd = Database.database().reference()
    let stockage = Storage.storage().reference()
    
    // Database
    var racineUtilisateur: DatabaseReference { return bdd.child("utilisateur")}
    var racinePost: DatabaseReference { return bdd.child("posts")}
    var racineHashtag: DatabaseReference { return bdd.child("hashtag")}
    var racineNotification: DatabaseReference { return bdd.child("notification")}

    
    var mesPostsBDD: DatabaseReference { return racinePost.child(MOI.id) }
    var mesNotifs: DatabaseReference { return racineNotification.child(MOI.id)}

    func notifUtilisateur(id: String) -> DatabaseReference {
        return racineNotification.child(id)
    }
    
    func utilisateurSpecifique(id: String) -> DatabaseReference {
        return racineUtilisateur.child(id)
    }
    
    func postUtilisateurSpecifique(id: String) -> DatabaseReference {
        return racinePost.child(id)
    }
    
    func postSpecifique(key: String, value: String) -> DatabaseReference {
        return postUtilisateurSpecifique(id: value).child(key)
    }
    
    
    func hashtagSpecifique(hashtag: String) -> DatabaseReference {
        return racineHashtag.child(hashtag)
    }
    
    func commentaireDepuisRef(ref: DatabaseReference) -> DatabaseReference {
        return ref.child("commentaires")
    }
    
    //Stockage
    var racinePostImage: StorageReference { return stockage.child("posts")}
    var mesPostsImage: StorageReference { return racinePostImage.child(MOI.id)}
    var racineProfilImage: StorageReference { return stockage.child("profil")}
    var monProfilImage: StorageReference { return racineProfilImage.child(MOI.id)}
}
