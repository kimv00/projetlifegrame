//
//  Stockage.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit
import FirebaseStorage

class Stockage {
    
    func ajouterPostImage(reference: StorageReference, data: Data, completion: SuccessCompletion?) {
        
        reference.putData(data, metadata: nil) { (meta, error) in
            if error == nil {
                reference.downloadURL(completion: { (url, error) in
                    if error == nil, let urlString = url?.absoluteString {
                        completion?(true, urlString)
                    } else {
                        completion?(false, error?.localizedDescription)
                    }
                })
            } else {
                completion?(false, error!.localizedDescription)
            }
        }
    }
    
    
    
}
