//
//  Typealias.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

typealias UtilisateurCompletion = (_ utilisateur: Utilisateur?) -> (Void)
typealias PostCompletion = (_ post: Post?) -> (Void)
typealias HashtagCompletion = (_ hashtag: Hashtag?) -> (Void)
typealias CommentaireCompletion = (_ commentaire: Commentaire?) -> (Void)
typealias NotifCompletion = (_ notif: Notif?) -> (Void)
typealias SuccessCompletion = (_ success: Bool?, _ string: String?) -> (Void)
