//
//  Notif.swift
//  LifeGram
//
//  Created by Toure on 03/06/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import Foundation
import FirebaseDatabase

class Notif {
    
    private var _ref: DatabaseReference!
    private var _id: String!
    private var _utilisateur: Utilisateur!
    private var _post: Post?
    private var _date: Double!
    private var _texte: String!
    private var _vue: Bool!
    
    var ref: DatabaseReference { return _ref}
    var id: String { return _id}
    var utilisateur: Utilisateur { return _utilisateur }
    var post: Post? { return _post }
    var date: Double { return _date }
    var texte: String { return _texte }
    var vue: Bool { return _vue}
    
    init(ref: DatabaseReference, id: String, utilisateur: Utilisateur, post: Post?, date: Double, texte: String, vue: Bool) {
        self._ref = ref
        self._id = id
        self._utilisateur = utilisateur
        self._post = post
        self._date = date
        self._texte = texte
        self._vue = vue
    }
    
    func modifierUtilisateur(utilsiateur: Utilisateur) {
        self._utilisateur = utilisateur
    }
    
}




