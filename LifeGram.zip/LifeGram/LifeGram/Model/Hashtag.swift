//
//  Hashtag.swift
//  LifeGram
//
//  Created by Toure on 03/06/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import Foundation

class Hashtag {
    
    private var _nom: String!
    private var _posts: [String: String]!
    
    var nom: String { return _nom}
    var posts: [String: String] { return _posts}
    
    init(nom: String, posts: [String: String]) {
        self._nom = nom
        self._posts = posts
    }
    
}
