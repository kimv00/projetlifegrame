//
//  PostVue.swift
//  CodaGram
//
//  Created by Matthieu PASSEREL on 21/01/2018.
//  Copyright © 2018 Matthieu PASSEREL. All rights reserved.
//

import UIKit

class PostVue: UIView {
    
    @IBOutlet weak var imageDeProfil: ImageArrondie!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var imageDuPost: UIImageView!
    @IBOutlet weak var nombreDeLike: UILabel!
    @IBOutlet weak var boutonLike: UIButton!
    @IBOutlet weak var nombreDeCommentaires: UILabel!
    @IBOutlet weak var boutonCommentaire: UIButton!
    @IBOutlet weak var textView: TextViewAvecHashtag!

    var vue: UIView!
    var post: Post!
    var filController: FilController?
    var profilController: ProfilController?
    var postUniqueController: PostUniqueController?
    var imageVueCoeur: UIImageView?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        vue = chargerXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        vue = chargerXib()
    }
    
    func miseEnPlace(post: Post, filController: FilController?, profilController: ProfilController?, postUniqueController : PostUniqueController?) {
        self.post = post
        self.filController = filController
        self.profilController = profilController
        self.postUniqueController = postUniqueController
        
        //Télécharger les images (profil + post)
        imageDeProfil.telecharger(imageUrl: self.post.utilisateur.imageUrl)
        imageDuPost.telecharger(imageUrl: self.post.imageUrl)
        
        //Ajout UsenameLabel
        usernameLabel.attributedText = usernameEtNom()
        
        //Ajout likes et commentaires en Int
        nombreDeLike.text = String(self.post.likes.count)
        nombreDeCommentaires.text = String(self.post.commentaires.count)
        observerNouveauCommentaire()
        
        //Mettre en place bouton Like si j'aime ou pas le post
        
        if self.post.likes.contains(MOI.id) {
            boutonLike.setImage(#imageLiteral(resourceName: "coeur_plein"), for: .normal)
        } else {
            boutonLike.setImage(#imageLiteral(resourceName: "coeur_vide"), for: .normal)
        }
        
        //Mettre en place customTextView avec les hashtags clickable
        textView.ajoutDuTexte(texte: self.post.texte, date: self.post.date)
        
        //Ajouter like si double tap sur notre image d profil
        imageDuPost.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(doubleTapImage))
        tap.numberOfTapsRequired = 2
        imageDuPost.addGestureRecognizer(tap)
        
        //Envoyer vers profil si tap profil ou usernameLabel
        imageDeProfil.isUserInteractionEnabled = true
        usernameLabel.isUserInteractionEnabled = true
        imageDeProfil.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(envoyerVersProfil)))
        usernameLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(envoyerVersProfil)))
        
    }
    
    func observerNouveauCommentaire() {
        var comms = [Commentaire]()
        BDD().recupererCommentaire(ref: self.post.ref) { (commentaire) -> (Void) in
            if let comm = commentaire {
                if let index = comms.index(where: {$0.id == comm.id}) {
                    comms[index] = comm
                } else {
                    comms.append(comm)
                }
                self.nombreDeCommentaires.text = String(self.post.commentaires.count)
            }
        }
    }
    
    @objc func envoyerVersProfil() {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        let controller = ProfilController(collectionViewLayout: layout)
        controller.utilisateur = self.post.utilisateur
        if filController != nil {
            filController?.navigationController?.pushViewController(controller, animated: true)
        } else if profilController != nil {
            profilController?.navigationController?.pushViewController(controller, animated: true)
        } else if postUniqueController != nil {
            postUniqueController?.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    @objc func doubleTapImage() {
        var mesLikes = self.post.likes
        if !mesLikes.contains(MOI.id) {
            mesLikes.append(MOI.id)
        }
        ajoutLikeEtNotification(mesLikes: mesLikes)
        if imageVueCoeur == nil {
            imageVueCoeur = UIImageView(frame: CGRect(x: 0, y: 0, width: frame.width / 2, height: frame.width / 2))
            imageVueCoeur?.image = #imageLiteral(resourceName: "coeur_double_tap")
            imageVueCoeur?.center = imageDuPost.center
            imageDuPost.addSubview(imageVueCoeur!)
            UIView.animate(withDuration: 0.5, animations: {
                self.imageVueCoeur?.transform = CGAffineTransform(scaleX: 1.25, y: 1.25)
            }, completion: { (success) in
                UIView.animate(withDuration: 0.5, animations: {
                    self.imageVueCoeur?.transform = CGAffineTransform.identity
                }, completion: { (success) in
                    self.imageVueCoeur?.removeFromSuperview()
                    self.imageVueCoeur = nil
                })
            })
        }
    }
    
    func usernameEtNom() -> NSMutableAttributedString {
        let mutable = NSMutableAttributedString(string: self.post.utilisateur.username, attributes: [.foregroundColor: UIColor.black, .font: UIFont.boldSystemFont(ofSize: 16)])
        let nomEtPrenomString = "\n" + self.post.utilisateur.prenom + " " + self.post.utilisateur.nom
        mutable.append(NSAttributedString(string: nomEtPrenomString, attributes: [.foregroundColor: UIColor.darkGray, .font: UIFont.systemFont(ofSize: 14)]))
        return mutable
    }
    
    func ajoutLikeEtNotification(mesLikes: [String]) {
        BDD().mettreAJourPost(postId: self.post.id, userId: self.post.utilisateur.id, dict: ["likes": mesLikes as AnyObject])
        BDD().recupererPostsHashtag(dict: [self.post.id: self.post.utilisateur.id]) { (post) -> (Void) in
            if post != nil {
                self.miseEnPlace(post: post!, filController: self.filController, profilController: self.profilController, postUniqueController: self.postUniqueController)
            }
        }
        if mesLikes.contains(MOI.id) && self.post.utilisateur.id != MOI.id {
            let dict: [String: AnyObject] = [
                "texte" : "A aimé votre post" as AnyObject,
                "date": Date().timeIntervalSince1970 as AnyObject,
                "utilisateur": MOI.id as AnyObject,
                "post": self.post.id as AnyObject,
                "vue": false as AnyObject
            ]
            BDD().envoyerNotification(id: self.post.utilisateur.id, dict: dict)
        }
    }
    
    @IBAction func boutonLikeAction(_ sender: Any) {
        var mesLikes = self.post.likes
        if boutonLike.imageView?.image == #imageLiteral(resourceName: "coeur_vide") {
            mesLikes.append(MOI.id)
        } else {
            if let index = mesLikes.index(of: MOI.id) {
                mesLikes.remove(at: index)
            }
        }
        ajoutLikeEtNotification(mesLikes: mesLikes)
    }
    
    
    
    @IBAction func boutonCommentaireAction(_ sender: Any) {
        let controller = CommentaireController()
        controller.commentaires = self.post.commentaires
        controller.post = self.post
        if filController != nil {
            filController?.navigationController?.pushViewController(controller, animated: true)
        } else if profilController != nil {
            profilController?.navigationController?.pushViewController(controller, animated: true)
        } else if postUniqueController != nil {
            postUniqueController?.navigationController?.pushViewController(controller, animated: true)
        }
    }
}








