//
//  ConnectionVue.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

class ConnectionVue: UIView {
    
    @IBOutlet weak var mailTextField: UITextField!
    @IBOutlet weak var motDePasseTextField: UITextField!
    @IBOutlet weak var ValiderBoutonTextField: LifeGramBouton!
    
    var vue: UIView!
    var connectionController: ConnectionController?

    override init(frame: CGRect) {
        super.init(frame: frame)
        vue = chargerXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        vue = chargerXib()
    }
    
    func ajoutController(controller: ConnectionController) {
        self.connectionController = controller
    }
    
    
    @IBAction func ValiderBoutonAction(_ sender: Any) {
        connectionController?.validerConnection(adresseMail: mailTextField.text, motDePasse: motDePasseTextField.text)
    }
    
}
