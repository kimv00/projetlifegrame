//
//  UsernameVue.swift
//  CodaGram
//
//  Created by Matthieu PASSEREL on 13/01/2018.
//  Copyright © 2018 Matthieu PASSEREL. All rights reserved.
//

import UIKit

class UsernameVue: UIView {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var erreurLabel: UILabel!
    
    var vue: UIView!
    var connectionController: ConnectionController?
    var peutCreerUsername = false
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        vue = chargerXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        vue = chargerXib()
    }
    
    func ajouterController(controller: ConnectionController) {
        self.connectionController = controller
        usernameTextField.addTarget(self, action: #selector(texteMisAJour), for: .editingChanged)
    }
    
    @IBAction func validerAction(_ sender: Any) {
        if usernameTextField.text != nil, peutCreerUsername {
            BDD().miseAjourUtilisateur(dict: ["username": usernameTextField.text! as AnyObject], completion: { (utilisateur) -> (Void) in
                if utilisateur != nil {
                    MOI = utilisateur!
                    //Peut passer au suivant
                    self.connectionController?.versApp()
                }
            })
        }
    }
    
    @IBAction func retourBouton(_ sender: Any) {
        connectionController?.transition(vers: (connectionController?.connectionVue)!, transition: .transitionFlipFromLeft)
    }
    
    @objc func texteMisAJour(_ textField: UITextField) {
        guard let nouveauUsername = textField.text else { return }
        if nouveauUsername == "" {
            peutCreerUsername = false
            erreurLabel.text = "Le nom d'utilisateur ne peut pas être vide"
        } else if nouveauUsername.contains(" ") {
            peutCreerUsername = false
            erreurLabel.text = "Le nom d'utilisateur ne peut pas contenir d'espace"
        } else if nouveauUsername.count >= 20 {
            peutCreerUsername = false
            erreurLabel.text = "Nom d'utilisateur trop long"
        } else {
            BDD().usernameExiste(username: nouveauUsername, completion: { (success, error) -> (Void) in
                guard success != nil, error != nil else { return }
                self.peutCreerUsername = success!
                self.erreurLabel.text = error!
            })
        }
    }
}





