//
//  ImageCarreCell.swift
//  LifeGram
//
//  Created by Toure on 28/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

let IMAGE_CARRE_CELL = "ImageCarreCell"

class ImageCarreCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
  

}
