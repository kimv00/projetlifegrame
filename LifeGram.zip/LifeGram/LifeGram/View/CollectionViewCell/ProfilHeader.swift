//
//  ProfilHeader.swift
//  CodaGram
//
//  Created by Matthieu PASSEREL on 23/01/2018.
//  Copyright © 2018 Matthieu PASSEREL. All rights reserved.
//

import UIKit

let PROFIL_HEADER = "ProfilHeader"


class ProfilHeader: UICollectionReusableView {
    
    @IBOutlet weak var imageDeFond: UIImageView!
    @IBOutlet weak var imageDeProfil: ImageArrondie!
    @IBOutlet weak var abonnesLabel: UILabel!
    @IBOutlet weak var abonnementsLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var boutonModifierOuSuivre: LifeGramBouton!
    
    @IBOutlet weak var textView: TextViewAvecHashtag!
    @IBOutlet weak var segmented: UISegmentedControl!
    
    var utilisateur: Utilisateur!
    var controller: ProfilController?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func miseEnPlace(controller: ProfilController, utilisateur: Utilisateur) {
        self.controller = controller
        self.utilisateur = utilisateur
        abonnesLabel.texteAvecAttributs(string1: String(utilisateur.abonnes.count), string2: "\n Abonnés")
        abonnementsLabel.texteAvecAttributs(string1: String(utilisateur.abonnements.count), string2: "\n Abonnements")
        usernameLabel.texteAvecAttributs(string1: utilisateur.username, string2: "\n" + utilisateur.prenom + " " + utilisateur.nom)
        textView.ajoutDuTexte(texte: utilisateur.desc,  date: nil)
        imageDeFond.telecharger(imageUrl: utilisateur.imageUrl)
        imageDeProfil.telecharger(imageUrl: utilisateur.imageUrl)
        
        if utilisateur.id == MOI.id {
            boutonModifierOuSuivre.setTitle("Modifier", for: .normal)
        } else if utilisateur.abonnes.contains(MOI.id) {
            boutonModifierOuSuivre.setTitle("Ne plus suivre", for: .normal)
        } else {
            boutonModifierOuSuivre.setTitle("Suivre", for: .normal)
        }
    }
    
    
    @IBAction func boutonAppuye(_ sender: Any) {
        if boutonModifierOuSuivre.titleLabel?.text == "Modifier" {
            let nouveauController = ModifierController()
            controller?.navigationController?.pushViewController(nouveauController, animated: true)
        } else {
            var suivre: Bool!
            if boutonModifierOuSuivre.titleLabel?.text == "Suivre" {
                suivre = true
            } else if boutonModifierOuSuivre.titleLabel?.text == "Ne plus suivre" {
                suivre = false
            }
            BDD().ajoutLike(utilisateur: self.utilisateur, suivre: suivre, completion: { (utilisateur) -> (Void) in
                if utilisateur != nil {
                    self.controller?.utilisateur = utilisateur!
                    self.controller?.collectionView?.reloadData()
                }
            })
        }
    }
    
    
    @IBAction func segmentChoisi(_ sender: Any) {
        if segmented.selectedSegmentIndex == 0 {
            controller?.postComplet = true
        } else {
            controller?.postComplet = false
        }
        controller?.collectionView?.reloadData()
    }

}

