//
//  ComentaireCell.swift
//  LifeGram
//
//  Created by Toure on 03/06/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

let COMMENTAIRE_TB = "ComentaireCell"

class ComentaireCell: UITableViewCell {
    
    @IBOutlet weak var imageDeProfil: ImageArrondie!
    @IBOutlet weak var nomLabel: UILabel!
    @IBOutlet weak var commentaireLabel: UILabel!
    
    var commentaire: Commentaire!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func miseEnPlace(commentaire: Commentaire) {
        self.commentaire = commentaire
        imageDeProfil.telecharger(imageUrl: self.commentaire.utilisateur.imageUrl)
        let string2 = "\n" + self.commentaire.utilisateur.prenom + " " + self.commentaire.utilisateur.nom
        nomLabel.texteAvecAttributs(string1: self.commentaire.utilisateur.username, string2: string2)
        commentaireLabel.texteAvecAttributs(string1: self.commentaire.texte, string2: "\n" + self.commentaire.date.ilYA())
    }
}









