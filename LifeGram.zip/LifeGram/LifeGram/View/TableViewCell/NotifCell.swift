//
//  NotifCell.swift
//  LifeGram
//
//  Created by Toure on 03/06/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.


import UIKit

let NOTIF_TB = "NotifCell"

class NotifCell: UITableViewCell {
    
    @IBOutlet weak var imagedeProfil: ImageArrondie!
    @IBOutlet weak var imageDuPost: UIImageView!
    @IBOutlet weak var notifDesc: UILabel!
    @IBOutlet weak var suivreBouton: LifeGramBouton!
    
    var notif: Notif!
    var controller: NotificationController?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func miseEnPlace(notif: Notif, controller: NotificationController) {
        self.notif = notif
        self.controller = controller
        imagedeProfil.telecharger(imageUrl: self.notif.utilisateur.imageUrl)
        imagedeProfil.isUserInteractionEnabled = true
        imagedeProfil.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(versProfil)))
        if self.notif.post == nil {
            imageDuPost.isHidden = true
            suivreBouton.isHidden = false
            if MOI.abonnements.contains(self.notif.utilisateur.id) {
                suivreBouton.setTitle("Ne plus suivre", for: .normal)
            } else {
                suivreBouton.setTitle("Suivre", for: .normal)
            }
        } else {
            imageDuPost.isHidden = false
            suivreBouton.isHidden = true
            imageDuPost.telecharger(imageUrl: self.notif.post!.imageUrl)
            imageDuPost.isUserInteractionEnabled = true
            imageDuPost.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(versPost)))
        }
        var string2 = "\n" + self.notif.date.ilYA() + "\n"
        switch self.notif.texte {
        case "A aimé votre post": string2 += self.notif.texte
        case "A commencé à vous suivre": string2 += self.notif.texte
        default: string2 += "A commenté: " + self.notif.texte
        }

        notifDesc.texteAvecAttributs(string1: self.notif.utilisateur.username, string2: string2)
        
    }
    
    @objc func versPost() {
        let postController = PostUniqueController()
        if let post = self.notif.post {
            postController.post = post
            controller?.navigationController?.pushViewController(postController, animated: true)
        }
    }
    
    @objc func versProfil() {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        let profilController = ProfilController(collectionViewLayout: layout)
        profilController.utilisateur = self.notif.utilisateur
        controller?.navigationController?.pushViewController(profilController, animated: true)
    }
    
    
    @IBAction func boutonAction(_ sender: Any) {
        var suivre: Bool!
        if suivreBouton.titleLabel?.text == "Suivre" {
            suivre = true
        } else {
            suivre = false
        }
        BDD().ajoutLike(utilisateur: self.notif.utilisateur, suivre: suivre) { (utilisateur) -> (Void) in
            if utilisateur != nil {
                self.notif.modifierUtilisateur(utilsiateur: utilisateur!)
                self.miseEnPlace(notif: self.notif, controller: self.controller!)
            }
        }
    }
}














