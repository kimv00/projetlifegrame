//
//  Constantes.swift
//  LifeGram
//
//  Created by Toure on 26/05/2018.
//  Copyright © 2018 Toure Issambou. All rights reserved.
//

import UIKit

var MOI: Utilisateur!
var NOTIF : [Notif]!
